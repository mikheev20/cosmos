const mysql = require('mysql');
const chokidar = require('chokidar');
const fs = require('fs');
const {Sequelize,DataTypes} = require('sequelize');
const { serialize } = require('v8');
const path = require('path');

const initDB = async() =>{
//-----------------------------------------------------OBJECT WITH FILE STRUCTURE CREATION------------------------------------------------------//

const fileTree = [];

function getFileTree (dir, files,item){
    
    files = files || [];

      var allFiles = fs.readdirSync(dir);
      for (var i =0; i<allFiles.length; i++){
        let name = dir + '/' + allFiles[i];
        const addItem = {
            name: allFiles[i],
            subcategories: [],
            items: []
        }
        if (!item){
            fileTree.push(addItem) 
        }else{
            fs.statSync(name).isDirectory() ? item.subcategories.push(addItem) : false;
        }
          if (fs.statSync(name).isDirectory()){
              getFileTree(name, files,addItem);
          } else {
              item.items.push(name);
          }
      }
      fs.writeFile('tree.txt',JSON.stringify(fileTree),(err) => {
        return err;
      })
      return;
  };
 await getFileTree(path.resolve(__dirname,'./archive'))

//---------------------------------------------------------------------------------------------------------------------------------------------//

//--------------------------------------------------------------DB CONNETION DATA----------------------------------------------------------------//

const sequelize = new Sequelize('test-eco','root','',{
    dialect: 'mysql',
    host: '127.0.0.1',
    port: '3306',
    dialectModule: require('mysql2'),
    dialectOptions: {
        connectTimeout: 600000
      },
      pool: {
        max: 20,
        min: 0,
        acquire: 600000,
        idle: 10000
      }
})

//----------------------------------------------------------------------------------------------------------------------------------------------//


//-----------------------------------------------------------------MODELS DEFINE----------------------------------------------------------------//
const News = sequelize.define('news',{
    title: {
        type: DataTypes.STRING,
        allowNull: false
    },
    text: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    date: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    filename: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    content: {
        type: DataTypes.BLOB('long'),
        allowNull: false,
    },
},{
    timestamps: false,
    createdAt: false
})
const Date = sequelize.define('date',{
    dateValue: {
        type: DataTypes.STRING,
        allowNull: false
    }
},{
    timestamps: false,
    createdAt: false
})

const ExtTimeframe = sequelize.define('extTimeframe',{
    extTimeValue: {
        type: DataTypes.STRING,
        allowNull: false
    }
},{
    timestamps: false,
    createdAt: false
})

const MapType = sequelize.define('mapType',{
    mapType: {
        type: DataTypes.STRING,
        allowNull:false
    }
},{
    timestamps: false,
    createdAt: false
})

const Country = sequelize.define('country',{
    countryName: {
        type: DataTypes.STRING,
        allowNull: false,
    }
},{
    timestamps: false,
    createdAt: false
})

const Map = sequelize.define('map',{
    mapLink: {
        type:DataTypes.STRING,
        allowNull:false
    }
},{
    timestamps: false,
    createdAt: false
})
Date.hasMany(ExtTimeframe);
ExtTimeframe.hasMany(MapType);
MapType.hasMany(ExtTimeframe);
MapType.hasMany(Country);
ExtTimeframe.hasMany(Country);
MapType.hasMany(Map);
Country.hasMany(Map);
Country.hasMany(MapType);
const dataInit = async() => {
    try{
        await sequelize.authenticate();
        console.log('Successfull connetion to db');    
    }catch(e){
        console.log(e.message)
    }
    
   await sequelize.query('SET FOREIGN_KEY_CHECKS = 0', { raw: true });
   await sequelize.sync ({ force: true });

    // await Date.sync({
    //     force: true
    // })
    // await ExtTimeframe.sync({
    //     force: true
    // })
    // await MapType.sync({
    //     force: true
    // })
    // await Country.sync({
    //     force: true
    // })
    // await Map.sync({
    //     force: true
    // })
    function createItem(itObj,tableName,isPropertyName,foreignKey,orderParam){
        const attrArr = Object.keys(tableName.getAttributes())[1];
        const createObj = {};
        if(foreignKey) {
            const key = Object.keys(tableName.getAttributes())[orderParam ? orderParam : 2].toString();
            createObj[key] = foreignKey;
        }
        Object.defineProperty(createObj,attrArr,{
            value: isPropertyName ? itObj.name : itObj,
            writable: true,
            enumerable: true,
            configurable: true,
        });
        return tableName.create(createObj)
    }
    // fs.statSync(__dirname + `/archive/${fileTree[l].name}/${fileTree[l]?.subcategories[i].name}/${fileTree[l]?.subcategories[i]?.subcategories[j].name}/${fileTree[l]?.subcategories[i]?.subcategories[j]}`).isDirectory()
    // console.log(fileTree[0].subcategories,fileTree.length);
    for(let l = 0;l<fileTree.length;l++){
        await createItem(fileTree[l],Date,true).then(async (dateRes) => {
            const dateId = dateRes.id;
            for(let i = 0;i<fileTree[l]?.subcategories.length;i++){
                await createItem(fileTree[l]?.subcategories[i],ExtTimeframe,true,dateId).then(async (timeRes) => {
                    const extTimeId = timeRes.id;
                    for(let j=0;j<fileTree[l]?.subcategories[i]?.subcategories.length;j++){
                        await createItem(fileTree[l]?.subcategories[i]?.subcategories[j],MapType,true,extTimeId).then(async (mapTypeRes) => {
                            const mapTypeId = mapTypeRes.id;
                            for(let k=0;k<(fileTree[l]?.subcategories[i]?.subcategories[j]?.items.length!=0 ? fileTree[l]?.subcategories[i]?.subcategories[j]?.items.length : fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories.length);k++){
                                if(!(fileTree[l]?.subcategories[i]?.subcategories[j]?.items.length==0 && fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories.length==0)){
                                    if (fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories.length!=0){
                                        if ((fileTree[l]?.subcategories[i]?.subcategories[j].name)=='local'){
                                            await createItem(fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k],ExtTimeframe,true,mapTypeId,3).then(async (localExtTimeFrame) => {
                                                const localExtTimeId = localExtTimeFrame.id;
                                                for(let y = 0;y<fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k]?.subcategories.length;y++){
                                                    await createItem(fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k]?.subcategories[y],Country,true,localExtTimeId,3).then(async (localCountry) => {
                                                        const localCountryId = localCountry.id;
                                                        for(let x=0;x<fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k]?.subcategories[y]?.subcategories.length;x++){
                                                            await createItem(fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k]?.subcategories[y]?.subcategories[x],MapType,true,localCountryId,3).then(async (localMapType) => {
                                                                const localMapTypeId = localMapType.id;
                                                                for(let u=0;u<fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k]?.subcategories[y]?.subcategories[x]?.items.length;u++){
                                                                    console.log(localMapTypeId);
                                                                    await createItem(fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k]?.subcategories[y]?.subcategories[x]?.items[u],Map,false,localMapTypeId)
                                                                }
                                                            })
                                                        }
                                                    })
                                                }
                                            })
                                        }else{
                                            await createItem(fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k],Country,true,mapTypeId).then(async (mapRes) => {
                                                const countryId = mapRes.id;
                                                if(fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k].items.length!=0){
                                                    for(let y = 0;y<fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k]?.items.length;y++){
                                                        console.log(fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k]?.items[y]);
                                                        await createItem(fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k]?.items[y],Map,false,countryId,3);
                                                    }}else{
                                                        false;
                                                    }
                                            })
                                        }}
                                    else{
                                        console.log()
                                        await createItem(fileTree[l]?.subcategories[i]?.subcategories[j]?.items[k],Map,false,mapTypeId); 
                                    }
                                }
                                else{
                                    false;
                                }
                                
                            }
                        })
        
                    }
                })
                
            }
        })
        
    }


}

await dataInit();

}

initDB();



// chokidar.watch('./archive').on('all',(event,path) => {
//     console.log(event,path);
// })

// if ((fileTree[l]?.subcategories[i]?.subcategories[j]?.name)=='local'){
    // await createItem(fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k],ExtTimeframe,true);
    // for(let y = 0;y<fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k].subcategories.length;y++){
    //     await createItem(fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k].subcategories[y],Country,true);
    //     for(let x=0;x<fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k].subcategories[y].subcategories.length;x++){
    //         await createItem(fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k].subcategories[y].subcategories[x],MapType,false);
    //         for(let u=0;u<fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k].subcategories[y].subcategories[x].items.length;u++){
    //             await createItem(fileTree[l]?.subcategories[i]?.subcategories[j]?.subcategories[k].subcategories[y].subcategories[x].items[u],Map,false)
    //         }
    //     }
    // }
// }else{