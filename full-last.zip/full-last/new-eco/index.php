<?php

header('Content-type: json/application');
require('./connect.php');
require('./functions.php');
require('./upload.php');

$type = $_GET['q'];
$method = $_SERVER['REQUEST_METHOD'];
    switch($type){
        case 'news':
            switch($method){
                case 'GET':
                    $id = $_GET['date'];
                    $limit = $_GET['extTimeframe'];
                    getNews($connect,$id,$limit);
                    break;
                case 'POST':
                    $body = $_POST;
                    $files = $_FILES;

                    if($body['id']){
                        updateNews($connect,$body,$files);
                    }else{
                        setNews($connect,$body,$files);
                    }
                    break;
                }
            break;
        case 'map':
            if(isset($_GET['country'])){

            }else {
                $dateValue = $_GET['date'];
                $extTimeFrameValue = $_GET['extTimeframe'];
                $mapTypeValue = $_GET['type'];
                $timeframeValue = $_GET['timeframe'];
                if(strpos($timeframeValue,'--')){
                    $countryArr = explode('--',$timeframeValue);
                    if(count($countryArr) < 3){
                        $countryValue = $countryArr[0];
                        $timeframeValue = $countryArr[1];
                    }else{
                        $isLocal = true;
                        $countryValue = $countryArr[0];
                        $timeframeValue = $countryArr[1];
                        $localMapTypeValue = $countryArr[2];
                        $localTimeFrameValue = $countryArr[3];
                    }
                }else{
                    if(ctype_digit($timeframeValue)){
                        false;
                    }else{
                        $timeframeValue = '';
                        $countryValue = $_GET['timeframe'];
                    } 
                }
                $dateId= mysqli_query($connect,"SELECT id FROM `dates` WHERE dateValue = '$dateValue'");
                while($dateRow = mysqli_fetch_array($dateId)){
                    $extTime = mysqli_query($connect,"SELECT id from `extTimeframes` WHERE dateId='$dateRow[0]' AND extTimeValue='$extTimeFrameValue'");
                    while($timeRow = mysqli_fetch_array($extTime)){
                        $mapType = mysqli_query($connect, "SELECT id from `mapTypes` WHERE extTimeframeId='$timeRow[0]' AND mapType='$mapTypeValue'");
                        $mapsArr = [];
                        $mapArr = [];
                        while($mapTypeRow = mysqli_fetch_array($mapType)){
                            if($countryValue && !$isLocal){
                                $countries = mysqli_query($connect,"SELECT id FROM `countries` WHERE mapTypeId='$mapTypeRow[0]' AND countryName='$countryValue'");
                                while ($countryRow = mysqli_fetch_array($countries)){
                                    $maps = mysqli_query($connect,"SELECT mapLink from `maps` WHERE countryId='$countryRow[0]'");
                                    while ($mapRow = mysqli_fetch_array($maps)){
                                        if(strpos($mapTypeValue,'meteogram')===0){
                                            if(isset($_GET['timeframe']) && !empty($timeframeValue) && strpos($mapRow['mapLink'],$timeframeValue)){
                                                $mapsArr[] =  substr($mapRow['mapLink'],strpos($mapRow['mapLink'],'archive'));
                                                break;
                                            }else{
                                                $mapArr[] = substr($mapRow['mapLink'],strpos($mapRow['mapLink'],'archive'));
                                            }
                                        }else{
                                            if(isset($_GET['timeframe']) && !empty($timeframeValue) && preg_replace('/[^0-9]/','',substr($mapRow['mapLink'],-12))==$timeframeValue){
                                                $mapsArr[] =  substr($mapRow['mapLink'],strpos($mapRow['mapLink'],'archive'));
                                                break;
                                            }else{
                                                $mapArr[] = substr($mapRow['mapLink'],strpos($mapRow['mapLink'],'archive'));
                                            }
                                        }
                                }
                                !$mapsArr ? $mapsArr=$mapArr : false;   
                                }
                            }else if($isLocal){
                                $localTimeFrames = mysqli_query($connect,"SELECT id FROM `extTimeframes` WHERE mapTypeId='$mapTypeRow[0]' AND extTimeValue='$timeframeValue'");
                                while ($timeFrameRow = mysqli_fetch_array($localTimeFrames)){
                                    $localCountries = mysqli_query($connect,"SELECT id FROM `countries` WHERE extTimeframeId='$timeFrameRow[0]' AND countryName='$countryValue'");
                                    while ($mapTypeRow = mysqli_fetch_array($localCountries)){
                                        $localMapType = mysqli_query($connect,"SELECT id FROM `mapTypes` WHERE countryId='$mapTypeRow[0]' AND mapType='$localMapTypeValue'");
                                        while ($mapRow = mysqli_fetch_array($localMapType)){
                                            $localMaps = mysqli_query($connect,"SELECT mapLink FROM `maps` WHERE mapTypeId='$mapRow[0]'");
                                            while ($localMapRow = mysqli_fetch_array($localMaps)){ 
                                                if(isset($_GET['timeframe']) && !empty($localTimeFrameValue) && substr(preg_replace('/[^0-9]/','',substr($localMapRow['mapLink'],-12)),1)==$localTimeFrameValue){
                                                        $mapsArr[] =  substr($localMapRow['mapLink'],strpos($localMapRow['mapLink'],'archive'));
                                                        break;
                                                }else{
                                                    $mapArr[] = substr($localMapRow['mapLink'],strpos($localMapRow['mapLink'],'archive'));
                                                }    
                                            }
                                            !$mapsArr ? $mapsArr=$mapArr : false;
                                        }
                                    }
                                }
                            }else{
                                $maps = mysqli_query($connect,"SELECT mapLink from `maps` WHERE mapTypeId='$mapTypeRow[0]'");
                                while ($mapRow = mysqli_fetch_array($maps)){
                                    if(strpos($mapTypeValue,'meteogram')===0){
                                        if(isset($_GET['timeframe']) && !empty($timeframeValue) && strpos($mapRow['mapLink'],$timeframeValue)){
                                            $mapsArr[] =  substr($mapRow['mapLink'],strpos($mapRow['mapLink'],'archive'));
                                            break;
                                        }else{
                                            $mapArr[] = substr($mapRow['mapLink'],strpos($mapRow['mapLink'],'archive'));
                                        }
                                    }else{
                                        if(isset($_GET['timeframe']) && !empty($timeframeValue) && preg_replace('/[^0-9]/','',substr($mapRow['mapLink'],-12))==$timeframeValue){
                                            $mapsArr[] =  substr($mapRow['mapLink'],strpos($mapRow['mapLink'],'archive'));
                                            break;
                                        }else{
                                            $mapArr[] = substr($mapRow['mapLink'],strpos($mapRow['mapLink'],'archive'));
                                        }
                                    }
                           }
                            !$mapsArr ? $mapsArr=$mapArr : false;
                            }
                        }
                        echo json_encode($mapsArr);
                    }
                }
            }
            break;
        case 'timeframes':
            $date = $_GET['date'];
            getTimeFrames($connect,$date);
            break;
        case 'dates':
            getDates($connect);
            break;
    }


