function setNews($connect,$data){
    $title = $data['title'];
    $text = $data['text'];
    $date = $data['date'];
    $img = $data['img'];
    mysqli_query($connect,"INSERT INTO `news`(`id`, `title`, `text`, `date`, `img`) VALUES (null,'$title','$text','$date','$img')");

    http_response_code(201);

    $res = [
        "status" => true,
        "post_id" => mysqli_insert_id($connect)
    ];

    echo json_encode($res);
}

function getNews($connect,$limit){
    if($limit){
        $news = mysqli_query($connect,"SELECT * FROM `news` LIMIT '$limit'");
    }else{
        $news = mysqli_query($connect,"SELECT * FROM `news`");
    }
    $newsList = [];
    while($newsItem = mysqli_fetch_assoc($news)){
        $newsList[] = $newsItem;
    }

    echo json_encode($newsList);
}

