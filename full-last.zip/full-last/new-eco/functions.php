<?php

function getTimeFrames($connect,$date){
    $dateId = mysqli_query($connect,"SELECT id FROM `dates` WHERE dateValue='$date'");
    while($dateRow = mysqli_fetch_array($dateId)){
        $timeFrames = mysqli_query($connect,"SELECT * FROM `extTimeframes` WHERE dateId='$dateRow[0]'");
    }
    $timeFramesList = [];
    while($timeFrameItem = mysqli_fetch_assoc($timeFrames)){
        $timeFramesList[] = $timeFrameItem;  
    }

    echo json_encode($timeFramesList);
}

function getDates($connect){
    $dates = mysqli_query($connect,'SELECT * FROM `dates`');
    $datesList = [];
    while($datesItem = mysqli_fetch_assoc($dates)){
        $datesList[] = $datesItem;
    }

    echo json_encode($datesList);
}
function getNews($connect,$id,$limit){
    if($id){
        $news = mysqli_query($connect,"SELECT * FROM `news` WHERE id='$id'");
    }else if($limit){
        $news = mysqli_query($connect,"SELECT * FROM `news` LIMIT '$limit'");
    }else{
        $news = mysqli_query($connect,"SELECT * FROM `news`");
    }
   
    $newsList = [];

    while($newsItem = mysqli_fetch_assoc($news)){
        $newsItem['content'] = base64_encode($newsItem['content']);
        $newsList[] = $newsItem;
    }

    echo json_encode($newsList,JSON_UNESCAPED_UNICODE);
}
function updateNews($connect,$body,$files){
    $uploadedFile = $files['file'];

    if($uploadedFile){
        $filename = $uploadedFile['name'];
        $fileContent = file_get_contents($uploadedFile['tmp_name']);
    }

    $allNews = mysqli_query($connect,'SELECT * FROM `news`');
    $id = $body['id'];

    $newsList = [];
    $oldNews = '';
    while($newsItem = mysqli_fetch_assoc($allNews)){
       if($newsItem['id'] == $id){ 
        $oldNews = $newsItem; 
        $newsList[] = $newsItem;
       }
    }
    $sql = "UPDATE news SET";

    $fieldsToUpdate = array();
    $params = array();

    foreach ($body as $field => $value) {
        if($field!=='id'){
            $fieldsToUpdate[] = " $field = ?";
            $params[] = $value;
        }
    }
    if($uploadedFile){
        $fieldsToUpdate[] = " filename = ?";
        $fieldsToUpdate[] = " content = ?";
        $params[] = $filename;
        $params[] = $fileContent;
    }

    $sql .= implode(",", $fieldsToUpdate);

    $sql .= " WHERE id = '$id'";
    $stmt = $connect->prepare($sql);
    $types = str_repeat('s', count($params));
    $stmt->bind_param($types,...$params);

    if ($stmt->execute()) {
        echo "Данные успешно обновлены";
    } else {
        echo "Ошибка при обновлении данных: " . $stmt->error;
    }

    // Закрытие подготовленного запроса
    $stmt->close();
}