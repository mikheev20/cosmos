<?php

function setNews($connect,$body,$files){
    
    $uploadedFile = $files['file'];

    $title = $body['title'];
    $text = $body['text'];
    $date = $body['date'];
    $filename = $uploadedFile['name'];
    $fileContent = file_get_contents($uploadedFile['tmp_name']);
    $stmt = $connect->prepare('INSERT INTO news (title, text, date, filename, content) VALUES (?, ?, ?, ?, ?)');
    $stmt->bind_param('sssss', $title, $text, $date, $filename, $fileContent);

    if ($stmt->execute()) {
        echo json_encode(['message' => 'File uploaded successfully']);
    } else {
        echo json_encode(['error' => 'Error uploading file']);
    }

    $stmt->close();
}
?>