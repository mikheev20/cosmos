import Head from 'next/head'
import Image from 'next/image'
import { Inter } from 'next/font/google'
import styles from '@/styles/Production.module.scss'
import Navbar from '@/components/Navbar/Navbar'
import classNames from 'classnames'
import Footer from '@/components/Footer/Footer'
import Select from '@/components/shared/Select/Select'
import Container from '@/components/shared/Container/Container'
import RangeSlider from '@/components/shared/RangeSlider/RangeSlider'
import { useEffect, useState } from 'react'
import { useGetMapsQuery,useGetDatesQuery, useGetTimeFramesQuery } from '@/redux/api/api'
import Controlls from '@/components/Controlls/Controlls'
import Timezones from '@/components/Timezones/Timezones'
import Loader from '@/components/shared/Loader/Loader'
import { useRouter } from 'next/router'
import { useDispatch, useSelector } from 'react-redux'
import { getDates } from '@/redux/features/datesSlice'

const inter = Inter({ subsets: ['cyrillic'] })
const asDirectoryArr = [
    {id:1,value: 'ca_6',subdirectories: [
        {id:1, name: 'Центральная Азия', value: 'ca',subdirectories: [{id:2,name:'h500_06',value:'h500_06'}, {id:3,name:'h500_06_bn',value:'h500_06_bn'}, {id:4,name:'pmsl_prec03h_clcm_06_n',value:'pmsl_prec03h_clcm_06_n'}, {id:5,name:'pmsl_vmax10m3h_wind10m_06_n',value:' '}, {id:19,name:'pmsl+prec03h+clcm_06_bn',value:'pmsl+prec03h+clcm_06_bn'}, {id:6,name:'prec_cld_pmsl_06',value:'prec_cld_pmsl_06'}, {id:7,name:'prec_pmsl_06',value:'prec_pmsl_06'}, {id:8,name:'prec12h_pmsl_06_n',value:'prec12h_pmsl_06_n'}, {id:9,name:'t_2m_06_mn',value:'t_2m_06_mn'}, {id:10,name:'t_2m_06_n',value:'t_2m_06_n'}, {id:20,name:'t_2m_t850_06_bn',value:'t_2m_t850_06_bn'}, {id:11,name:'t2_06',value:'t2_06'}, {id:12,name:'t2_h500_pmsl_06',value:'t2_h500_pmsl_06'}, {id:13,name:'t2_h500_pmsl_06_c',value:'t2_h500_pmsl_06_c'}, {id:14,name:'vmax10m_max24_06_n',value:'vmax10m_max24_06_n'}, {id:15,name:'wind10_06',value:'wind10_06'}, {id:16,name:'wind10_gust_06',value:'wind10_gust_06'}, {id:17,name:'wind850_remhum850_06',value:'wind850_remhum850_06'}, {id:18,name:'wind850_remhum850_b',value:'wind850_remhum850_b'}]},
        {id: 2, name: 'Горный регион', value: 'mountCA',subdirectories: [{id:1,name:'ot500-1000_06',value:'ot500-1000_06'}, {id:2,name:'pmsl_prec03h_clcm_06_mn',value:'pmsl_prec03h_clcm_06_mn'}, {id:3,name:'pmsl_vmax10m3h_wind10m_06_mn',value:'pmsl_vmax10m3h_wind10m_06_mn'}, {id:4,name:'prec12h_pmsl_06_mn',value:'prec12h_pmsl_06_mn'}]},
        {id: 3, name: 'Республика Узбекистан',value: 'uz',subdirectories: [{id:1,name:'pmsl_prec03h_clcm',value:'pmsl_prec03h_clcm',isLocal: true,extTimeFrame:'06'}, {id:2,name:'pmsl_vmax10m3h_wind10m',value:'pmsl_vmax10m3h_wind10m',isLocal: true,extTimeFrame:'06'}, {id:3,name:'prec12h_pmsl',value:'prec12h_pmsl',isLocal: true,extTimeFrame:'06'}, {id:4,name:'t_2m',value:'t_2m',isLocal: true,extTimeFrame:'06'}]},
        {id: 4, name: 'Республика Кыргызская',value: 'krg',subdirectories: [{id:1,name:'h500',value:'h500',isLocal: true,extTimeFrame:'06'}, {id:2,name:'ot500-1000',value:'ot500-1000',isLocal: true,extTimeFrame:'06'}, {id:3,name:'prec_cld_pmsl',value:'prec_cld_pmsl',isLocal: true,extTimeFrame:'06'}, {id:4,name:'prec_cld_pmsl_b',value:'prec_cld_pmsl_b',isLocal: true,extTimeFrame:'06'}, {id:5,name:'prec_pmsl',value:'prec_pmsl',isLocal: true,extTimeFrame:'06'}, {id:7,name:'t2_h500_pmsl',value:'t2_h500_pmsl',isLocal: true,extTimeFrame:'06'}, {id:8,name:'t2m',value:'t2m',isLocal: true,extTimeFrame:'06'}, {id:9,name:'t2mc_h500_pmcl',value:'t2mc_h500_pmcl',isLocal: true,extTimeFrame:'06'}, {id:10,name:'wind10',value:'wind10',isLocal: true,extTimeFrame:'06'}, {id:11,name:'wind10_gust',value:'wind10_gust',isLocal: true,extTimeFrame:'06'}, {id:13,name:'wind850_remhum850',value:'wind850_remhum850',isLocal: true,extTimeFrame:'06'}]},
        {id: 5, name: 'Республика Таджикистан',value: 'taj',subdirectories: [{id:1,name:'h500',value:'h500',isLocal: true,extTimeFrame:'06'}, {id:2,name:'ot500-1000',value:'ot500-1000',isLocal: true,extTimeFrame:'06'}, {id:3,name:'prec_cld_pmsl',value:'prec_cld_pmsl',isLocal: true,extTimeFrame:'06'}, {id:4,name:'prec_cld_pmsl_b',value:'prec_cld_pmsl_b',isLocal: true,extTimeFrame:'06'}, {id:5,name:'prec_pmsl',value:'prec_pmsl',isLocal: true,extTimeFrame:'06'}, {id:7,name:'t2_h500_pmsl',value:'t2_h500_pmsl',isLocal: true,extTimeFrame:'06'}, {id:8,name:'t2m',value:'t2m',isLocal: true,extTimeFrame:'06'}, {id:9,name:'t2mc_h500_pmcl',value:'t2mc_h500_pmcl',isLocal: true,extTimeFrame:'06'}, {id:10,name:'wind10',value:'wind10',isLocal: true,extTimeFrame:'06'}, {id:11,name:'wind10_gust',value:'wind10_gust',isLocal: true,extTimeFrame:'06'}, {id:13,name:'wind850_remhum850',value:'wind850_remhum850',isLocal: true,extTimeFrame:'06'}]},
    ]},
    {id:2,value: 'ca_2',subdirectories: [
        {id: 1, name: 'Горный регион', value: 'mountCA',subdirectories: [{id:1,name:'h500_02',value:'h500_02',extTimeFrame:'02'}, {id:2,name:'ot500-1000_02',value:'ot500-1000_02',extTimeFrame:'02'}, {id:3,name:'pmsl_vmax10m1h_wind10m_02',value:'pmsl_vmax10m1h_wind10m_02',extTimeFrame:'02'}, {id:4,name:'prec_cld_pmsl_02',value:'prec_cld_pmsl_02',extTimeFrame:'02'}, {id:5,name:'prec_cld_pmsl_02_b',value:'prec_cld_pmsl_02_b',extTimeFrame:'02'}, {id:6,name:'prec_pmsl_02',value:'prec_pmsl_02',extTimeFrame:'02'}, {id:7,name:'prec12h_pmsl_02',value:'prec12h_pmsl_02',extTimeFrame:'02'}, {id:8,name:'t_2m_02',value:'t_2m_02',extTimeFrame:'02'}, {id:9,name:'t_2m_t850_02',value:'t_2m_t850_02',extTimeFrame:'02'}, {id:10,name:'t2_02',value:'t2_02',extTimeFrame:'02'}, {id:11,name:'t2_h500_pmsl_02',value:'t2_h500_pmsl_02',extTimeFrame:'02'}, {id:12,name:'t2_h500_pmsl_02_c',value:'t2_h500_pmsl_02_c',extTimeFrame:'02'}, {id:13,name:'t850_02',value:'t850_02',extTimeFrame:'02'}, {id:14,name:'wind10_02',value:'wind10_02',extTimeFrame:'02'}, {id:15,name:'wind10_gust_02',value:'wind10_gust_02',extTimeFrame:'02'}, {id:16,name:'wind850_remhum850_02',value:'wind850_remhum850_02',extTimeFrame:'02'}]},
        {id: 2, name: 'Республика Узбекистан',value: 'uz',subdirectories: [{id:1,name:'pmsl_vmax10m1h_wind10m',value:'pmsl_vmax10m1h_wind10m',isLocal: true,extTimeFrame:'02'}, {id:2,name:'pmsl+prec01h+clcm',value:'pmsl+prec01h+clcm',isLocal: true,extTimeFrame:'02'}, {id:3,name:'prec12h_pmsl',value:'prec12h_pmsl',isLocal: true,extTimeFrame:'02'}, {id:4,name:'t_2m',value:'t_2m',isLocal: true,extTimeFrame:'02'}, {id:5,name:'t_2m+t850',value:'t_2m+t850',isLocal: true,extTimeFrame:'02'}, {id:6,name:'t850',value:'t850',isLocal: true,extTimeFrame:'02'}]},
        {id: 3, name: 'Республика Кыргызская',value: 'krg',subdirectories: [{id:1,name:'h500',value:'h500',isLocal: true,extTimeFrame:'02'}, {id:2,name:'ot500-1000',value:'ot500-1000',isLocal: true,extTimeFrame:'02'}, {id:3,name:'prec_cld_pmsl',value:'prec_cld_pmsl',isLocal: true,extTimeFrame:'02'}, {id:4,name:'prec_cld_pmsl_b',value:'prec_cld_pmsl_b',isLocal: true,extTimeFrame:'02'}, {id:5,name:'prec_pmsl',value:'prec_pmsl',isLocal: true,extTimeFrame:'02'}, {id:7,name:'t2_h500_pmsl',value:'t2_h500_pmsl',isLocal: true,extTimeFrame:'02'}, {id:8,name:'t2m',value:'t2m',isLocal: true,extTimeFrame:'02'}, {id:9,name:'t2mc_h500_pmcl',value:'t2mc_h500_pmcl',isLocal: true,extTimeFrame:'02'}, {id:10,name:'wind10',value:'wind10',isLocal: true,extTimeFrame:'02'}, {id:11,name:'wind10_gust',value:'wind10_gust',isLocal: true,extTimeFrame:'02'}, {id:13,name:'wind850_remhum850',value:'wind850_remhum850',isLocal: true,extTimeFrame:'02'}]},
        {id: 4, name: 'Республика Таджикистан',value: 'taj',subdirectories: [{id:1,name:'h500',value:'h500',isLocal: true,extTimeFrame:'02'}, {id:2,name:'ot500-1000',value:'ot500-1000',isLocal: true,extTimeFrame:'02'}, {id:3,name:'prec_cld_pmsl',value:'prec_cld_pmsl',isLocal: true,extTimeFrame:'02'}, {id:4,name:'prec_cld_pmsl_b',value:'prec_cld_pmsl_b',isLocal: true,extTimeFrame:'02'}, {id:5,name:'prec_pmsl',value:'prec_pmsl',isLocal: true,extTimeFrame:'02'}, {id:7,name:'t2_h500_pmsl',value:'t2_h500_pmsl',isLocal: true,extTimeFrame:'02'}, {id:8,name:'t2m',value:'t2m',isLocal: true,extTimeFrame:'02'}, {id:9,name:'t2mc_h500_pmcl',value:'t2mc_h500_pmcl',isLocal: true,extTimeFrame:'02'}, {id:10,name:'wind10',value:'wind10',isLocal: true,extTimeFrame:'02'}, {id:11,name:'wind10_gust',value:'wind10_gust',isLocal: true,extTimeFrame:'02'}, {id:13,name:'wind850_remhum850',value:'wind850_remhum850',isLocal: true,extTimeFrame:'02'}]},
    ]},
    {id:3,value: 'meteogram',subdirectories: [
        {id: 1, name: 'Республика Узбекистан', value: 'uzb',subdirectories: [{id:1,name:'Метеограммы-CA6',value:'meteogram_06'},{id:2,name:'Метеограммы-CA2',value:'meteogram_02'}]},
        {id: 2, name: 'Республика Казахстан',value: 'kzh',subdirectories: [{id:1,name:'Метеограммы-CA6',value:'meteogram_06'},{id:2,name:'Метеограммы-CA2',value:'meteogram_02'}]},
        {id: 3, name: 'Республика Таджикистан',value: 'tdj',subdirectories: [{id:1,name:'Метеограммы-CA6',value:'meteogram_06'},{id:2,name:'Метеограммы-CA2',value:'meteogram_02'}]},
    ]}
]
const optionArr = [
    {id: 1, name: 'Карты прогнозов COSMO-CA6',value: 'ca_6'},
    {id: 2,name: 'Карты прогнозов COSMO-CA2',value: 'ca_2',default: false},
    {id: 3, name: 'Метеограммы',value: 'meteogram',default: false}
]
const country_tdj = ['Aivadj','Anzob','Dangara','Darvoz','Dehavz','Dushanbe','Farhor','Fayzabad','Horog','Hovaling','Irht','Isambay','Ishakshim,','Iskanderkul','Istaravshan','Karakul','Kayrakkym','Khujand','Kurgan-Tube','Madrushkat','Murgab','Penjikent','Rasht','Rushan','Sanglok','Shanristan'];
const country_kzh = ['Aktau','Aktobe','Almaty','Atyrau','Karaganda','Kokeshtau','Kostanai','Kyzylorda','Nur-Sultan','Pavlodar','Petropavlovsk','Semey','Shymkent','Taldykurgan','Taraz','Uralsk','Ust-Kamenogorsk','Zhezkazgan'];
const country_uzb = ['Andijan','Bukhara','Djizak','Fergana','Guliston','Kamchik','Karshi','Kushka','Namangan','Navoi','Nukus','Nurafshon','Samarkand','Tashkent','Termez','Urgench','Ustasaroy'];
export default function Production() {
    const dispatch = useDispatch();
    const state = useSelector(state => state.dates);
    const router = useRouter();
    const [activeTimeFrame,setActiveTimeFrame] = useState('');
    const [countryArr,setCountryArr] = useState([]);
    const [timeZonesArr,setTimeZonesArr] = useState([]);
    const [isMapActive,setIsMapActive] = useState(false);
    const backgrounds = [{name: 'kzh',path: 'kzh.png'},{name: 'krg',path: 'krg.png'},{name: 'uz',path: 'uz.png'},{name: 'tdj',path: 'tdj.png'}];
    const [backgroundValue,setBackgroundValue] = useState('');
    const [extTimeFrameValue,setExtTimeFrameValue] = useState('');
    const [category,setCategory] = useState('');
    const [production,setProduction] = useState('');
    const [mapType,setMapType] = useState('');
    const [country,setCountry] = useState('');

    const {data: dates,isFetching: isDatesLoading} = useGetDatesQuery();
    const [date,setDate] = useState('');
    const {data: timeFrames} = useGetTimeFramesQuery({date: date});
    const [timeFrameValue,setTimeFrameValue] = useState(activeTimeFrame);
    const [srcValue,setSrcValue] = useState('');
    const {data: map,isFetching: isMapLoading} = useGetMapsQuery({date:date,extTimeFrame:extTimeFrameValue,mapType: production.isLocal ? 'local/':production,timeFrame: production.isLocal ?country + '--' + production?.extTimeFrame + '--' + production?.value + '--' + timeFrameValue : country !== 'ca' && country!=='mountCA' && country ? country + '--' + timeFrameValue : timeFrameValue});
    const{data: maps,isFetching: isMapsLoading} = useGetMapsQuery({date:date,extTimeFrame:extTimeFrameValue,mapType: production.isLocal ? 'local/':production,timeFrame: production.isLocal ?country + '--' + production?.extTimeFrame + '--' + production?.value : country !== 'ca' && country!=='mountCA' && country ? country : null});
    const [intervalID,setIntervalID] = useState(null);
    const [animSpeed,setAnimSpeed] = useState(1000);

    const mapsForSort = maps ? [...maps].sort((a,b) => {
        if(parseInt(a.slice(-11,-9).replace(/[^+\d]/g, ''),10)>parseInt(b.slice(-11,-9).replace(/[^+\d]/g, ''),10)){
            return 1;
        }
        if(parseInt(a.slice(-11,-9).replace(/[^+\d]/g, ''),10)<parseInt(b.slice(-11,-9).replace(/[^+\d]/g, ''),10)){
            return -1;
        }

        return 0;
    }) : [];
    useEffect(() => {
        if(maps && map){
            setSrcValue(map[0] && map[0]!==undefined ? map[0] : maps[0]);
        }
    },[map,maps])
    useEffect(() => {
        if(!isDatesLoading){
            dispatch(getDates(dates));
        }
   },[isDatesLoading])
   useEffect(() => {
        setActiveTimeFrame('');
        setTimeZonesArr([]);
        switch(category){
            case 'meteogram':
                switch(country){
                    case 'kzh':
                        setCountryArr(country_kzh);
                        break;
                    case 'tdj':
                        setCountryArr(country_tdj);
                        break;
                    case 'uzb':
                        setCountryArr(country_uzb);
                        break;
                };
                setTimeZonesArr(maps?.map(item => {
                    if(countryArr.indexOf(item.slice(item.lastIndexOf('_')+1,item.lastIndexOf('.'))) != -1){
                        return item.slice(item.lastIndexOf('_')+1,item.lastIndexOf('.'))
                    }else{
                        return item.slice(item.lastIndexOf('_',item.lastIndexOf('_')-1)+1,item.lastIndexOf('_'))
                    }
                }).sort((a,b) => {
                    return a-b;    
                }))
                !activeTimeFrame && timeZonesArr ? setActiveTimeFrame(timeZonesArr[0]) : setActiveTimeFrame(timeZonesArr?.filter(item => item==activeTimeFrame)[0]);
                break;
            default:
                setTimeZonesArr(maps?.map(item => {
                    if(parseInt(item.slice(item.lastIndexOf('_')+1)).toString().length == 1){
                        return parseInt('1' + item.slice(parseInt(item.lastIndexOf('_')+1))).toString().slice(1);
                    }else{
                        return parseInt(item.slice(item.lastIndexOf('_')+1));
                    }
                }).sort((a,b) => {
                    return a-b;  
                }));
                !activeTimeFrame && timeZonesArr ? setActiveTimeFrame(timeZonesArr[0]) : setActiveTimeFrame(timeZonesArr?.filter(item => item==activeTimeFrame)[0]);
                break;
        }
   },[category,country,maps])
   useEffect(() => {
    !activeTimeFrame && timeZonesArr ? setActiveTimeFrame(timeZonesArr[0]) : setActiveTimeFrame(timeZonesArr?.filter(item => item==timeFrameValue)[0]);
   },[timeZonesArr,timeFrameValue])
    // const changeImage = () => {
    //     setImageValue()
    //     setInterval(changeImage,1000);
    // }
    function onPlayBtn(){
        if (intervalID == null){
            setIntervalID(setInterval(() => {animateMaps()}, animSpeed)); 
        }
    }
    function onPauseBtn(){
        if (intervalID !== null){
        clearInterval(intervalID);
        setIntervalID(null);
        }
    }
    function onSpeedChange(){
        clearInterval(intervalID);
        if(animSpeed !== 200){
            setAnimSpeed(oldSpeed => oldSpeed-200);
        }else{
            setAnimSpeed(1000);
        }
        setIntervalID(setInterval(() => {animateMaps()}, animSpeed));
    }
    function animateMaps(){
                setSrcValue(oldValue => {
                    if(oldValue !== mapsForSort[mapsForSort?.length -1]){
                        return mapsForSort[mapsForSort.indexOf(oldValue) + 1];
                    }
                    return mapsForSort[0];
                })
    }
    return (
        <div className={styles.production}>
            <div className={styles.productionInner}>
            <header className={styles.header}>
          <Navbar router={router}/>
          </header>
          <div className={styles.mapSelection}>
            <div className={styles.mapBox}>
            <Container>
            <div className={styles.selectors}>
                <Select setValueToRequest={(value) => {setCategory(value)}} options={optionArr} title='Категория'/>
                <Select backgroundChanger={() => setIsMapActive(true)} setValueToRequest={ async (value) => {setCountry(value)}} options={asDirectoryArr.filter(item => item.value == category).map(item => item.subdirectories)[0]} title='Страны'/>
                <Select setValueToRequest={(value) => {setProduction(value)}} options={asDirectoryArr.filter(item => item.value == category)[0]?.subdirectories.filter(item => item.value == country)[0]?.subdirectories} title='Продукция'/>
                <Select setValueToRequest={(value) => {setDate(value)}} options={state?.dates} title='Дата'/>
            </div>
            <div className={styles.contentManage}>
                    <Select setValueToRequest={(value) => {setExtTimeFrameValue(value)}} options={timeFrames} title='Интервал'/>
                    {maps?.length!==1 || maps==[] ?<Controlls onPauseBtn={onPauseBtn} onPlayBtn={onPlayBtn} onSpeedChange={onSpeedChange}>
                        <RangeSlider imageSlider={maps} value={mapsForSort?.indexOf(srcValue) } maxValue={maps?.length} onChangeCallback={(index) => {setSrcValue(mapsForSort[index])}}/>
                    </Controlls> : null}
                    </div>
            <div className={styles.mainContent}>
                <div className={classNames(styles.contentItem,styles.itemTimezones)}>
                    {maps&&srcValue ? <Timezones activeTimeFrame={activeTimeFrame} country={country} category={category} onClickFunc={(timeFrame) => setTimeFrameValue(timeFrame)} timeFrames={timeZonesArr}/> : false}
                </div>
                <div className={classNames(styles.contentItem,styles.itemMap)}>
                    {!srcValue  ? <div className={styles.noData}>Данных по вашему запросу не найдено</div> :<div className={styles.imageChanger}><img src={srcValue}/></div>}
                </div>
            </div>
            </Container>
            <div className={styles.backgroundChanger}>
                {backgrounds.map(item => <img key={item.name} className={classNames(styles.background,item.name==country || country=='uz' && item.name=='uzb' || country=='uzb' && item.name=='uz' ||country=='taj' && item.name=='tdj' ||country=='tdj' && item.name=='taj' ? styles.__active : null)} src={item.path}/>)}
                <img  className={classNames(styles.background,styles.main,isMapActive && country!=='mountCA' && country!=='ca' ? styles.__active : null,country!=='mountCA' && country!=='ca' ? `${country}-fill` : null)} src='full.png'/>
                <div className={styles.backgroundOverflow}></div>
            </div>
            </div>
          </div>
          {(isMapLoading || isMapsLoading) && (!category || !date || !country || !extTimeFrameValue) ? <Loader/>  : null}

          <Footer/>
            </div>
        </div>
      )
  }

