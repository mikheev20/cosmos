import Head from 'next/head'
import Image from 'next/image'
import { Inter } from 'next/font/google'
import styles from '@/styles/Home.module.scss'
import Navbar from '@/components/Navbar/Navbar'
import classNames from 'classnames'
import LinkBtn from '@/components/shared/LinkBtn/LinkBtn'
import About from '@/components/page-blocks/About/About'
import Footer from '@/components/Footer/Footer'
import NewsBlock from '@/components/page-blocks/News/NewsBlock'

const inter = Inter({ subsets: ['cyrillic'] })

export default function Home({host}) {
  return (
    <>
      <header className={styles.header}>
      <Navbar/>
      <div className={styles.headerMain}>
        <div className={styles.headerInner}>
        <h1 className={styles.headerTitle}>
        АГЕНТСТВО ГИДРОМЕТЕОРОЛОГИЧЕСКОЙ СЛУЖБЫ 
        <span>ПРИ МИНИСТЕРСТВЕ ЭКОЛОГИИ, ОХРАНЫ ОКРУЖАЮЩЕЙ СРЕДЫ И ИЗМЕНЕНИЯ КЛИМАТА РЕСПУБЛИКИ УЗБЕКИСТАН</span>
        </h1>
        <p className={classNames(styles.textInfo,inter.className,'textInfo')}>
        Ваш надежный проводник в мире погоды. Точные прогнозы, безопасность и актуальные данные для ваших решений.
        </p>
        </div>
      </div>
      </header>
      <About/>
      <NewsBlock/>
      <Footer/>
    </>
  )
}
