import Footer from '@/components/Footer/Footer'
import Navbar from '@/components/Navbar/Navbar'
import Container from '@/components/shared/Container/Container'
import { useGetNewsQuery } from '@/redux/api/api'
import { useRouter } from 'next/router'
import React from 'react'
import styles from '../../styles/NewsDetail.module.scss';
import classNames from 'classnames'
import { Inter } from 'next/font/google'


const inter = Inter({subsets: ['cyrillic']});
export default function NewsItemPage() {
    const router = useRouter();
    const {id} = router.query;

    const {data: news} = useGetNewsQuery({id});
  return (
    <div>
        <Navbar/>
        <Container>
            <div className={styles.itemInner}>
            <h2 className={classNames('page-block__title',styles.itemTitle,inter.className)}>{news ? news[0].title : ''}</h2>
            <div className={styles.itemImagebox}>
                <img className={styles.itemImage} src={news ? 'data:image/jpeg;base64, ' + news[0].content : ''} alt='news image'/>
            </div>
            <p className={classNames(styles.itemText,'page-block__text',inter.className)}>{news ? news[0].text : ''}</p>
            <div className={classNames(styles.itemDate,inter.className)}>{news ? news[0].date : ''}</div>
            </div>
        </Container>
        <Footer/>
    </div>
  )
}
