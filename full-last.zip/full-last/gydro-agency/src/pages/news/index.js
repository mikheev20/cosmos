import Container from '@/components/shared/Container/Container'
import { useGetNewsQuery } from '@/redux/api/api'
import React from 'react'
import styles from '../../components/page-blocks/News/NewsBlock.module.scss';
import Link from 'next/link';
import classNames from 'classnames';
import { Inter } from 'next/font/google';
import Navbar from '@/components/Navbar/Navbar';
import Footer from '@/components/Footer/Footer';

const inter = Inter({ subsets: ['cyrillic'] });

export default function News() {
    const {data: news} = useGetNewsQuery();
  return (
    <div className='page-block'>
        <Navbar/>
        <Container>
            <div className='page-block__inner'>
                <h2 className={classNames('page-block__title',inter.className)}>Новости</h2>
                <p className={classNames('page-block__text',inter.className)}>
                Наша команда экспертов по гидрометеорологии постоянно следит за развитием событий, проводит исследования и анализ данных, чтобы обеспечить вас самой актуальной информацией
                </p>
                <div className={styles.items}>
                {news?.map(item => 
            <div key={item.id} className={styles.newsItem}>
                <div className={styles.itemImagebox}>
                    <img className={styles.image} src={'data:image/jpeg;base64, ' + item.content} alt='news image'/>
                </div>
                <div className={styles.itemInfobox}>
                    <h6 className={styles.itemTitle}>{item.title}</h6>
                    <Link className={classNames(styles.itemLink, inter.className)} href={`news/${item.id}`}>
                        Подробнее
                    </Link>
                </div>
            </div>)}
                </div>
            </div>
        </Container>
        <Footer/>
    </div>
  )
}
