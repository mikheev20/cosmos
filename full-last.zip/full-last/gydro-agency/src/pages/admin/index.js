import { Inter } from 'next/font/google';
import styles from '../../styles/Admin.module.scss';
import classNames from 'classnames';
import { useGetNewsQuery, useSetNewsMutation, useUpdateNewsMutation } from '@/redux/api/api';
import { useEffect, useState } from 'react';

const inter = Inter({subsets: ['cyrillic']});
export default function AdminPanel(){
    const [isPosted,setIsPosted] = useState(false);

    const [title,setTitle] = useState('');
    const [text,setText] = useState('');
    const [date,setDate] = useState('');
    const [img,setImg] = useState('');
    const[editNewsItem,setEditNewsItem] = useState('');
    const [editTitle,setEditTitle] = useState();
    const [editText,setEditText] = useState();
    const [editDate,setEditDate] = useState();
    const [editImg,setEditImg] = useState('');

    useEffect(() => {
        setEditTitle(editNewsItem.title);
        setEditText(editNewsItem.text);
        setEditDate(editNewsItem.date);
    },[editNewsItem])

    const [createNews] = useSetNewsMutation();
    const [updateNews] = useUpdateNewsMutation();
    const {data: news} = useGetNewsQuery();

    return (
        <div className={styles.admin}>
            <h2 className={classNames(styles.title,inter.className)}>АДМИН ПАНЕЛЬ</h2>
           <div className={styles.inner}>
            <div className={styles.adminItem}>
                <h3 className={classNames(styles.subtitle,inter.className)}>Все новости</h3>
                <div className={styles.itemInner}>
                <div className={styles.newsItemTop}>
                            <div className={styles.newsItemColumn}>Номер</div>
                            <div className={styles.newsItemColumn}>Заголовок</div>
                            <div className={styles.newsItemColumn}>Дата</div>
                            <div className={styles.newsItemColumn}>Управление</div>
                        </div>
                    {news?.map((item,index) => 
                        <div key={item.id} className={styles.newsItem}>
                        <div className={styles.newsItemColumn}>{index+1}</div>
                            <div className={styles.newsItemColumn}>{item.title}</div>
                            <div className={styles.newsItemColumn}>{item.date}</div>
                            <div className={styles.newsItemColumn}>
                                <div onClick={() => {
                                    setEditNewsItem(item);
                                }} className={styles.newsItemBtn}>Ред.</div>
                                <div className={styles.newsItemBtn}>Удалить</div>
                            </div>
                    </div>
                        )}
                </div>
            </div>
            <div className={styles.adminItem}>
                <h3 className={classNames(styles.subtitle,inter.className)}>Редактирование</h3>
                <div className={classNames(styles.itemInner,styles.formBlock)}>
                    <input className={styles.input} placeholder='Название новости' value={editTitle} onChange={(e) => setEditTitle(e.target.value)}></input>
                    <textarea className={styles.textarea} placeholder='Текст новости' value={editText} onChange={(e) => setEditText(e.target.value)}></textarea>
                    <input type='date' value={editDate} onChange={(e) => setEditDate(e.target.value)}/>
                    <input type='file' className={styles.input} placeholder='Изображение новости' onChange={(e) => setEditImg(e.target.files[0])}></input>
                    <button onClick={() => {
                        const formData = new FormData();
                        formData.append('id',editNewsItem?.id);
                        formData.append('title',editTitle);
                        formData.append('text',editText);
                        formData.append('date',editDate);
                        editImg ? formData.append('file',editImg) : null;

                        createNews(formData);
                        setIsPosted(true);
                    }} type='submit'>Обновить</button>
                </div>
            </div>
            <div className={styles.adminItem}>
                <h3 className={classNames(styles.subtitle,inter.className)}>Добавить новость</h3>
                <div className={classNames(styles.itemInner,styles.formBlock)}>
                    <input className={styles.input} placeholder='Название новости' value={title} onChange={(e) => setTitle(e.target.value)}></input>
                    <textarea className={styles.textarea} placeholder='Текст новости' value={text} onChange={(e) => setText(e.target.value)}></textarea>
                    <input type='date' value={date} onChange={(e) => setDate(e.target.value)}/>
                    <input type='file' className={styles.input} placeholder='Изображение новости' onChange={ async (e) =>{
                            setImg(e.target.files[0]);
                        }
                        }></input>
                    <button onClick={() => {
                        const formData = new FormData();
                        formData.append('title',title);
                        formData.append('text',text);
                        formData.append('date',date);
                        formData.append('file',img);

                        createNews(formData);
                        setIsPosted(true);
                    }}>Добавить</button>
                </div>
            </div>
           </div>
        </div>
    )
}

