import React from 'react'
import styles from './Footer.module.scss';
import Logo from '../shared/Logo/Logo';
import Container from '../shared/Container/Container';
import classNames from 'classnames';
import { Inter } from 'next/font/google';

const inter = Inter({subsets: ['cyrillic']});

export default function Footer() {
  return (
    <footer className={classNames(styles.footer,inter.className)}>
        <Container>
        <div className={styles.inner}>
        <div className={styles.footerItem}>
            <Logo className={styles.logo}/>
            <div className={styles.copyright}>Copyright © 2023 <span>Все права защищены</span></div>
        </div>
        <div className={styles.footerItem}>
            <div className={styles.menu}>
                <ul className={styles.menuList}>
                    <li className={classNames(styles.menuTitle,inter.className)}>Компания</li>
                    <li className={styles.menuItem}>О нас</li>
                    <li className={styles.menuItem}>Продукция</li>
                    <li className={styles.menuItem}>Новости</li>
                </ul>
                <ul className={styles.menuList}>
                    <li className={classNames(styles.menuTitle,inter.className)}>Поддержка</li>
                    <li className={styles.menuItem}>Политика конфиденциальности</li>
                </ul>
                <ul className={styles.menuList}>
                    <li className={classNames(styles.menuTitle,inter.className)}>Контакты</li>
                    <li className={styles.menuItem}>
                        <a href='tel: +998 90 123 45 67' className={styles.phone}>+998 90 123 45 67</a>
                    </li>
                    <li className={styles.menuItem}>
                        <a href='mail: hydrometeorology@gmail.com' className={styles.mail}>hydrometeorology@gmail.com</a>
                    </li>
                </ul>
            </div>
        </div>
        </div>
        </Container>
    </footer>
  )
}
