import React, { useEffect, useRef, useState } from 'react'
import styles from './Select.module.scss';
import classNames from 'classnames';
import { Inter } from 'next/font/google';

const inter = Inter({subsets: ['cyrillic']});

export default function Select({category,backgroundChanger,options,setValueToRequest,title}) {
        const [defaultValue,setDefaultValue] = useState('');
        const [isActive,setIsActive] = useState(false);
        useEffect(() => {
            if(options?.length!=0 && options && setValueToRequest){
                setDefaultValue(options[0][Object.keys(options[0])[1]]);
                options[0].isLocal ? setValueToRequest(options[0].hasOwnProperty('value') ? {value: options[0].value,isLocal: true,extTimeFrame: options[0].extTimeFrame} : {value: options[0][Object.keys(options[0])[1]],isLocal: true}) : setValueToRequest(options[0].hasOwnProperty('value') ? options[0].value : options[0][Object.keys(options[0])[1]]);
            }
        },[options])
        return (
            <div className={classNames(styles.selectBox,inter.className)} onClick={() => {
                setIsActive(oldValue => !oldValue)
            }}>
            <h4 className={classNames(styles.title,inter.className)}>{title}</h4>
            <div className={classNames(styles.select, isActive ? styles.__active : '')}>
            <div className={styles.default}>{defaultValue}</div>
            <div style={{maxHeight: isActive ? 250 + 'px' : 0,overflowY:options?.length>5 && isActive ? 'scroll' : 'hidden'}} className={styles.selectMenu} >
                {options?.map(item => <div key={item.id} data-value={item.hasOwnProperty('value') ? item.value : item[Object.keys(item)[1]]} onClick={(e) => {
                    if(backgroundChanger){
                        backgroundChanger();
                    }
                    setDefaultValue(item[Object.keys(item)[1]]);
                    item.isLocal ? setValueToRequest({value: e.target.dataset.value,isLocal: true,extTimeFrame: item.extTimeFrame}): setValueToRequest(e.target.dataset.value);
                }} className={classNames(styles.option,item.default)}>{item[Object.keys(item)[1]]}</div>)}
            </div>
            </div>
        </div>
          )
}
