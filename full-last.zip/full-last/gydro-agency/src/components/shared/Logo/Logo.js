import Link from 'next/link'
import React from 'react'
import styles from './Logo.module.scss';
import classNames from 'classnames';

export default function Logo({className}) {
  return (
    <Link className={classNames(styles.logo,className)} href='/'>
        <img src='logo.svg' alt='icon: logo icon'/>
    </Link>
  )
}
