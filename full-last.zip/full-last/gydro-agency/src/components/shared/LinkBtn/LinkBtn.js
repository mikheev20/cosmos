import React from 'react'
import styles from './LinkBtn.module.scss';
import Link from 'next/link';
import classNames from 'classnames';
import { Inter } from 'next/font/google';

const inter = Inter({subsets: ['cyrillic']});

export default function LinkBtn({href,text}) {
  return (
    <Link href={href} className={classNames(styles.btn,inter.className)}>
        {text}
    </Link>
  )
}
