import Link from 'next/link'
import React from 'react'
import styles from './LinkComp.module.scss';
import { Inter } from 'next/font/google';
import { useRouter } from 'next/router';
import classNames from 'classnames';

const inter = Inter({subsets: ['cyrillic']});


export default function LinkComp({className,href,title}) {
    const router = useRouter();

  return (
    <Link className={classNames(className,router.asPath == href ? styles.__active : null)} href={href}>{title}</Link>
  )
}
