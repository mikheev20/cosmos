import React, { useRef } from 'react'
import styles from './RangeSlider.module.scss';

export default function RangeSlider({value,maxValue,onChangeCallback}) {
    const inputRef = useRef(null);
    const thumbRef = useRef(null);
    
    const thumbPosition = value / (maxValue-1);

    const space = inputRef?.current?.offsetWidth - thumbRef?.current?.offsetWidth;
  return (
    <div className={styles.rangeSlider}>
    <div className={styles.content}>
        <div className={styles.slider}>
            <div style={{width: ((value * (100/maxValue))) + '%'}} className={styles.sliderLine} id="range-line"></div>
        </div>
        <div ref={thumbRef} style={{left: (thumbPosition*space)+'px'}} className={styles.sliderThumb} id="range-thumb">

        </div>

        <input ref={inputRef} className={styles.input} type='range' min={0} max={maxValue ? maxValue-1 : null} step={1} value={value?value : ''} onChange={(e) => {
        onChangeCallback ? onChangeCallback(e.target.value) : null;
    }}/>
    </div>
</div>

  )
}
