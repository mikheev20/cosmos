import React from 'react'
import styles from './Controlls.module.scss';

export default function Controlls({onPauseBtn,onSpeedChange,onPlayBtn,children}) {
  return (
    <div className={styles.controlls}>
        <div className={styles.buttons}>
            <div onClick={onPauseBtn} className={styles.btn}>
                <img src='pause.svg'/>
            </div>
            <div onClick={onPlayBtn} className={styles.btn}>
                <img src='play.svg'/>
            </div>
            <div onClick={onSpeedChange} className={styles.btn}>
                <img src='forward.svg'/>
            </div>
        </div>
        {children}
    </div>
  )
}
