import Container from '@/components/shared/Container/Container';
import classNames from 'classnames'
import { Inter } from 'next/font/google'
import React, { useEffect, useState } from 'react'
import styles from './NewsBlock.module.scss';
import Link from 'next/link';
import { useGetNewsQuery } from '@/redux/api/api';

const inter = Inter({subsets: ['cyrillic']});

export default function NewsBlock() {
    const {data: news} = useGetNewsQuery();
  return (
    <section id='news' className={classNames(styles.section,inter.className,'blockSection')}>
        <Container>
        <h2 className={classNames(styles.title,'blockTitle')}>Новости</h2>
        <p className={classNames(styles.textInfo,inter.className,'textInfo')}>
        Наша команда экспертов по гидрометеорологии постоянно следит за развитием событий, проводит исследования и анализ данных, чтобы обеспечить вас самой актуальной информацией
        </p>
        <div className={styles.newsItems}>
            {news?.map(item => 
            <div key={item.id} className={styles.newsItem}>
                <div className={styles.itemImagebox}>
                    <img className={styles.image} src={'data:image/jpeg;base64, ' + item.content} alt='news image'/>
                </div>
                <div className={styles.itemInfobox}>
                    <h6 className={styles.itemTitle}>{item.title}</h6>
                    <Link className={classNames(styles.itemLink, inter.className)} href={`news/${item.id}`}>
                        Подробнее
                    </Link>
                </div>
            </div>
            )}
        </div>
        <Link href='news' className={styles.more}>
            Читать больше
        </Link>
        </Container>
    </section>
  )
}
