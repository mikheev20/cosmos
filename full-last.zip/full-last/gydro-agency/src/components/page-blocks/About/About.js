import React from 'react'
import styles from './About.module.scss';
import Container from '@/components/shared/Container/Container';
import classNames from 'classnames';
import { Inter } from 'next/font/google';

const inter = Inter({subsets: ['cyrillic']})

export default function About() {
  return (
    <section id='about' className={classNames(styles.section,inter.className,'blockSection')}>
        <Container>
        <h2 className={classNames(styles.title,'blockTitle')}>О нас</h2>
        <div className={styles.aboutItems}>
          <div className={styles.aboutImagebox}>
            <img src='about.png' alt='image: about image'/>
          </div>
          <div className={styles.aboutInfobox}>
            <h3 className={styles.infoboxTitle}>
            АГЕНТСТВО ГИДРОМЕТЕОРОЛОГИЧЕСКОЙ СЛУЖБЫ ПРИ МИНИСТЕРСТВЕ ЭКОЛОГИИ, ОХРАНЫ ОКРУЖАЮЩЕЙ СРЕДЫ И ИЗМЕНЕНИЯ КЛИМАТА РЕСПУБЛИКИ УЗБЕКИСТАН
            </h3>
            <p className={classNames(styles.infoboxText,'blockText')}>
            Региональный специализированный метеорологический центр (РСМЦ) является национальным и региональным центром сбора, обработки и распространения гидрометеорологической и спутниковой информации в системе Всемирной службы погоды (ВСП) Всемирной Метеорологической Организации (ВМО).
            </p>
          </div>
        </div>
        </Container>
      </section>
  )
}
