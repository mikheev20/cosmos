import React, { useState } from 'react'
import styles from './Navbar.module.scss';
import Link from 'next/link';
import Container from '../shared/Container/Container';
import Logo from '../shared/Logo/Logo';
import { Inter } from 'next/font/google';
import classNames from 'classnames';
import LinkComp from '../shared/LInkComp/LinkComp';

const inter = Inter({subsets: ['cyrillic']});

export default function Navbar({router}) {
    const [isBurgerActive,setIsBurgerActive] = useState(false);
  return (
    <div className={classNames(styles.navbarWrapper,inter.className)}>
        <Container>
        <nav className={styles.navbar}>
        <Logo className={styles.logo}/>
        <ul className={classNames(styles.menuList,isBurgerActive ? styles.__active : null)}>
            <li onClick={() => setIsBurgerActive(old => !old)} className={styles.menuListItem}>
                <LinkComp className={classNames(inter.className)} href='/' title={'Главная'}/>
            </li>
            <li onClick={() => setIsBurgerActive(old => !old)} className={styles.menuListItem}>
                <LinkComp className={classNames(inter.className)} href='/production' title={'Продукция'}/>
            </li>
            <li onClick={() => setIsBurgerActive(old => !old)} className={styles.menuListItem}>
                <LinkComp className={classNames(inter.className)} href='#about' title={'О нас'}/>
            </li>
            <li onClick={() => setIsBurgerActive(old => !old)} className={styles.menuListItem}>
                <LinkComp className={classNames(inter.className)} href='news' title={'Новости'}/>
            </li>
        </ul>
        <div className={styles.right}>
        <div className={styles.lang}>
            RU
        </div>
        <div onClick={() => {
            setIsBurgerActive(old => !old)
        }} className={classNames(styles.burger,isBurgerActive ? styles.__active : null)}>
            <span></span>
        </div>
        </div>
    </nav>
    </Container>
    </div>
  )
}
