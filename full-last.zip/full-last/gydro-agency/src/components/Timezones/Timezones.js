import React, { useState } from 'react'
import styles from './Timezones.module.scss';
import Select from '../shared/Select/Select';
import { Inter } from 'next/font/google';
import classNames from 'classnames';

const inter = Inter({subsets: ['cyrillic']});
export default function Timezones({activeTimeFrame,category,extTimeFrames,onClickFunc,timeFrames}) {
    if(timeFrames){
        switch(category){
            case 'meteogram':
                return (
                    <div className={classNames(styles.timezones,inter.className,styles.meteogramTimezones)}>
                        <div className={styles.timezonesBox}>
                        <div className={classNames(styles.inputTitle,inter.className)}>Выберите город:</div>
                        <div className={classNames(styles.timezonesInner,styles.meteogramInner)}>
                        {timeFrames?.map((item,index) => <div key={index} className={classNames(item==activeTimeFrame ? styles.__active : null, styles.timezonesItem,styles.meteogramItem)} data-value={item} onClick={(e) => {onClickFunc(e.target.dataset.value)}}>{item}</div>)}
                        </div>
                        </div>
                    </div>
                  )
                break;
            default:
                return (
                    <div className={classNames(styles.timezones,inter.className)}>
                        <div className={styles.timezonesBox}>
                        <div className={classNames(styles.inputTitle,inter.className)}>Выберите интервал:</div>
                        <div className={styles.timezonesInner}>
                        {timeFrames?.map((item,index) => <div key={index} className={classNames(item==activeTimeFrame ? styles.__active : null, styles.timezonesItem)} data-value={item} onClick={(e) => {onClickFunc(e.target.dataset.value)}}>{item}</div>)}
                        </div>
                        </div>
                    </div>
                  )
                break;
        }
    }
    else{
        return false;
    }
}
