import { createApi,fetchBaseQuery } from "@reduxjs/toolkit/query/react";

const baseQuery = fetchBaseQuery({
    baseUrl: "http://new-eco/",
  })

  export const apiSlice = createApi({
    baseQuery: baseQuery,
    endpoints: (builder) => ({
      getMaps: builder.query({
        query: ({date,extTimeFrame,mapType,timeFrame}) => timeFrame ? `map/${date}/${extTimeFrame}/${mapType}/${timeFrame}` : `map/${date}/${extTimeFrame}/${mapType}`,
      }),
      getDates : builder.query({
        query: () => 'dates/',
      }),
      getNews : builder.query({
        query: (params) => ({
          url: params ? `news/${params.id}/${params.limit}` : `news/`,
          method: 'GET',
        }),
      }),
      getTimeFrames : builder.query({
        query: ({date}) => `timeframes/${date}`,
      }),
      setNews: builder.mutation({
        query: (body) => ({
          url: 'news/',
          method:'POST',
          body,
        })
      }),
      updateNews: builder.mutation({
        query: (body) => ({
          url: 'news/',
          method: 'PATCH',
          body,
        })
      })
    }),
  })

  export const { useGetMapsQuery,useGetDatesQuery,useGetTimeFramesQuery,useGetNewsQuery,useSetNewsMutation,useUpdateNewsMutation } = apiSlice;