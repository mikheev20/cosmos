import { configureStore } from "@reduxjs/toolkit";
import {apiSlice} from './api/api'
import datesSlice from "./features/datesSlice";

const store = configureStore({
    reducer: {
        [apiSlice.reducerPath]: apiSlice.reducer,
        dates: datesSlice,
    },
    middleware: getDefaultMiddleware => getDefaultMiddleware().concat(apiSlice.middleware),
    devTools: true,
})

export default store;