const { createSlice } = require("@reduxjs/toolkit");

const initialState = {
    dates: [],
}

const datesSlice = createSlice({
    name: 'dates',
    initialState:initialState,
    reducers: {
        getDates(state,action){
            state.dates = action.payload;
        }
    } 
})

export const {getDates} = datesSlice.actions;

export default datesSlice.reducer;